package Pizzeria;
import java.util.Scanner;

public class main {

    public static void main(String[] args) {
    	
    	String[] Pizze = {"Margherita", "Marinara", "Patatine e Wurstel", "Napoli"};
        // Crea un buffer condiviso
        BufferO bo = new BufferO();
        BufferP bp = new BufferP();
        BufferC bc = new BufferC();
        BufferT bt = new BufferT();

        // Crea istanze 
        Tavolo tavolo = new Tavolo(bo, bt);
        Cameriere cameriere = new Cameriere(bo, bp, bc, bt, Pizze);
        Pizzaiolo pizzaiolo = new Pizzaiolo(bp, bc, Pizze);

        // Crea thread 
        Thread tavoloThread = new Thread(tavolo);
        Thread pizzaioloThread = new Thread(pizzaiolo);
        
        Thread[] cameriereThread = new Thread[3];
        for(int i = 0; i < 3; i++) {
        	cameriereThread[i] = new Thread(cameriere);
        	Thread.currentThread().setName("Cameriere-" + (i + 1));        
        }
        
        // Avvia i thread
		tavoloThread.start();
        pizzaioloThread.start();
        for(int i = 0; i < 3; i++) {
        	cameriereThread[i].start();
        }
        
        

        // Aggiungi un'attesa per far terminare la simulazione (per evitare che il main termini subito)
        try (Scanner scanner = new Scanner(System.in)) {
            //Premi INVIO per terminare il programma...
            scanner.nextLine(); // Attende l'input dell'utente per fermare l'esecuzione

            // Terminare i thread
            tavoloThread.interrupt();
            pizzaioloThread.interrupt();
            for(int i = 0; i < 3; i++) {
            	cameriereThread[i].interrupt();
            }

            // Attende la terminazione dei thread
            tavoloThread.join();
            pizzaioloThread.join();
            for(int i = 0; i < 3; i++) {
            	cameriereThread[i].join();
            }

            System.out.println("Programma terminato.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
