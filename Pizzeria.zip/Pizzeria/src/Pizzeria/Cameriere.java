package Pizzeria;
import java.util.Random;

public class Cameriere implements Runnable {

	private BufferO bo;
	private BufferP bp;
	private BufferC bc;
	private BufferT bt;
	private String[]TipoDiPizze;
	private Random random = new Random();
    private boolean isRun = true;
	
	Cameriere(BufferO bo, BufferP bp,BufferC bc, BufferT bt, String[]arr){
		this.bo = bo;
		this.bp = bp;
		this.bc = bc;
		this.bt = bt;
		this.TipoDiPizze=arr;
	}

	@Override
	public void run() {
		while (isRun) {
			try {
                // Legge un numero dal buffer
                int q = bo.getQuantita();
                System.out.println("");
                System.out.println(Thread.currentThread().getName() + ": Le Pizze da fare sono " + q);
                int[]pizze = bo.getQualiPizze(); 
                bp.putQuantita(q);
                bp.putQualiPizze(pizze);
                
                for(int i = 0; i < q; i++) {
                	System.out.println("Una " + TipoDiPizze[pizze[i]]);
                }
                
                System.out.println("");
                
                q = bc.getQuantita();
                pizze = bc.getQualiPizze();
                
                bt.putQualiPizze(pizze);
                bt.putQuantita(q);
                
             // Attende un tempo casuale tra 2 e 3 secondi
                int sleepTime = random.nextInt(1001) + 2000;
                Thread.sleep(sleepTime);
                
                System.out.println("");
                System.out.println(Thread.currentThread().getName() + ": Ho ricevuto " + q + " pizze");
                for(int i = 0; i < q; i++) {
                	System.out.print("Una " + TipoDiPizze[pizze[i]]);
                	if(i != q - 1) {
                		System.out.print(", ");
                	}else {
                		System.out.print(". ");
                	}
                }
                
                System.out.println("");
                System.out.println("E le porto al tavolo");
                

            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                isRun = false;
            }
		
		}
            

	}

}


