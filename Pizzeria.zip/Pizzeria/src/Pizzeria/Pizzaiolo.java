package Pizzeria;

public class Pizzaiolo implements Runnable {
	
	private BufferP bp;
	private BufferC bc;
	private String[]TipoDiPizze;
    private boolean isRun = true;
	
	Pizzaiolo(BufferP bo,BufferC bc, String[]arr){
		this.bp = bo;
		this.bc = bc;
		this.TipoDiPizze=arr;
	}

	@Override
	public void run() {
		while (isRun) {
			try {
                // Legge un numero dal buffer
                int q = bp.getQuantita(); 
                int[]pizze = bp.getQualiPizze(); 
                
                bc.putQualiPizze(pizze);
                bc.putQuantita(q);
                
                System.out.println("Pizzaiolo: ho sfornato " + q + " pizze");
                for(int i = 0; i < q; i++) {
                	System.out.print("Una " + TipoDiPizze[pizze[i]]);
                	if(i != q - 1) {
                		System.out.print(", ");
                	}else {
                		System.out.print(". ");
                	}
                }
                
                System.out.println("");

            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                isRun = false;
            }
		
		}
            

	}

}
