package Pizzeria;

public class BufferT {
	private int quantita;
 	private int[] QualiPizze;
    private boolean available1 = false;
    private boolean available2 = false;

    public synchronized void putQuantita(int value) throws InterruptedException {
        while (available1) {
            wait(); // Aspetta finché il buffer non è consumato
        }
        this.quantita = value;
        available1 = true;
        notifyAll(); // Notifica il consumatore che il nuovo valore è disponibile
    }
    
    public synchronized int getQuantita() throws InterruptedException {
        while (!available1) {
            wait(); // Aspetta finché non c'è un valore disponibile
        }
        available1 = false;
        notifyAll(); // Notifica il produttore che il buffer è stato svuotato
        return quantita;
    }
    
    public synchronized void putQualiPizze(int[]arr) throws InterruptedException {
        while (available2) {
            wait(); // Aspetta finché il buffer non è consumato
        }
        this.QualiPizze = arr;
        available2 = true;
        notifyAll(); // Notifica il consumatore che il nuovo valore è disponibile
    }
    
    public synchronized int[] getQualiPizze() throws InterruptedException {
        while (!available2) {
            wait(); // Aspetta finché non c'è un valore disponibile
        }
        available2 = false;
        notifyAll(); // Notifica il produttore che il buffer è stato svuotato
        return QualiPizze;
    }


}
