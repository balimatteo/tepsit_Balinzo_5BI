package Pizzeria;
import java.util.Random;


public class Tavolo implements Runnable {
	
	private BufferO bo;
	private BufferT bt;
	private Random random = new Random();
	private boolean isRun = true;
	
	Tavolo(BufferO bo, BufferT bt ){
		this.bo = bo;
		this.bt = bt;
	}

	@Override
	public void run() {
		while (isRun) {
            try {
            	
            	int quantita = random.nextInt(5);
            	quantita++;
            	
                bo.putQuantita(quantita);
                
                int[]QualiPizze = new int[quantita];
                
                for(int i = 0; i < quantita; i++) {
                	QualiPizze[i] = random.nextInt(3);
                }
                
                bo.putQualiPizze(QualiPizze);
                
                int q = bt.getQuantita();
                
             // Attende un tempo casuale tra 4 e 5 secondi
                int sleepTime = random.nextInt(1001) + 4000;
                Thread.sleep(sleepTime);
                System.out.println("");
                System.out.println("Sono arrivate al tavolo " + q + " pizze");
                
                
             // Attende un tempo casuale tra 9 e 10 secondi
                int sleepTime1 = random.nextInt(1001) + 9000;
                Thread.sleep(sleepTime1);
                

            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                isRun = false;
            }
        }

	}

}
